clear
close all
%% Setting the harvester parameters:
m=10^(-3);%proof mass (m) in kg.
k=0.17;%Spring constant in kg.s^2
b=0.0055;%Spring damping factor kg/s
% the proof mass displacement limit Zl is setted in the simulink file to be 0.01 meter

%% Reading the accelerometer input file, 
%This file has 4 columns:
%the first one is the time, 
%the second, third and the fourth ones are the measured x-axial, y-axial and z-axial acceleration, respectively. 
%PLEASE SPECIFY THE PATH OF THE INPUT FILE IN THE COMMAND BELOW
Acc=xlsread('C:\Users\Sara\Documents\MATLAB\Release\Assignment\Walking1.csv'); 
 
%% Plotting the input accelerometer signal
figure,plot(Acc(:,1),Acc(:,2))
hold on
plot(Acc(:,1),Acc(:,3),'r')
plot(Acc(:,1),Acc(:,4),'g')
hold off
legend ('X Axis', 'Y Axis', 'Z Axis')
title('\bf Accelerometer Measurements');xlabel('Time (s)');ylabel(' Acceleration (m/s.s)')

%% Claculating the overall magnitude of acceleration

a=sqrt(Acc(:,2).^2+Acc(:,3).^2+Acc(:,4).^2);

%% Filtring the gravity using a 3rd order Butterworth high-pass filter with a 0.1 Hz cutoff frequency
%applying the frequency domian on overal magnitude of acceleration
F=fft(a); 
% specifying a 3rd order Butterworth filter with a 0.1 Hz cutoof frequency
[num,den]=butter(3,0.1,'high'); 
[H,w]=freqz(num,den,length(a)); 
% applying the previously specified filter to the frequency transfomation of the overall acceleration
y=H.*F;
% applying the inverse frequency domain transformation and getting the real part
FilteredAcc=real(ifft(y));

%%preparing the simulink file input simin as a two column variable, the
%%first column is the time and the second column is the filtered
%%acceleration
simin=[Acc(:,1),FilteredAcc];


%% Calling the simulink file which includes the mass spring damping system
sim('PowerHarvester',(length(simin(:,1))/100));
% reading the output of the simulink file both time and power values
P=[simout.time,simout.data];
%plotting the power output in \mu watt 
figure,plot(simout.time,(simout.data*1000000))
title('\bf Estimated Harvested Power');xlabel('Time (s)');ylabel(' Power (\muW)')
